Sevgili Engin Hocam ve bunu gören herkese merhabalar, göreceğiniz üzere ödevi yetiştiremedim. Çünkü köpeğim ödevimi yedi 😂 demek istedirdim fakat işyerindeki yoğunluk ve yeni evlenmenin getirdiği bazı görevler sebebiyle anca günde oluşturabildiğim 15-20dk lık süreçler içinde bakabildim.
Bu sebeple ben işten ayrılmayı ciddi şekilde düşünmekteyim. İlk ödevde dahi bu kadar yetişemeyeceğimi tahmin etmemiştim.
Bundan sonraki ödevlerde daha özverili ve işten ayrılırsam daha bol zamanlı çalışacağımı taahüt ederim.

Saygılarımla.

ps. kodlar biraz spagetti oldu. (sebebi tek oturuşta odaklanıp yapmadığım için.)